from setuptools import setup

with open('README.md', 'r') as file:
    long_description = file.read()

setup(long_description=long_description, long_description_content_type='text/markdown')
